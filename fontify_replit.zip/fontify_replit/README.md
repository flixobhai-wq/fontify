# Fontify

A static, mobile-friendly stylish text generator built with plain HTML, CSS and JavaScript.

## Run on Replit
1. Create a new **HTML, CSS, JS** Replit project (or import this ZIP).
2. Upload `index.html` to the project root.
3. Press **Run** to preview the site.
4. To publish, open **Deployments** and choose **Static** (if available for your Replit account), then deploy the project. The entry file is `index.html`.

No server, API key, or package installation is required.
